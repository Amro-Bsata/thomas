---
'openzeppelin-solidity': minor
---

`MerkleTree`: Add an update function that replaces a previously inserted leaf with a new value, updating the tree root along the way.
