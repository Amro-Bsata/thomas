---
"openzeppelin-solidity": patch
---

`MessageHashUtils`: Add `toDataWithIntendedValidatorHash(address, bytes32)`.
