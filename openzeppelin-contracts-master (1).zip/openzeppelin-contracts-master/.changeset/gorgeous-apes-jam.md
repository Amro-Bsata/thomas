---
'openzeppelin-solidity': minor
---

`TimelockController`: Receive function is now virtual.
