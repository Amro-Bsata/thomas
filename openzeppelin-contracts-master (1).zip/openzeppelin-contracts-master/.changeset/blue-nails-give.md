---
'openzeppelin-solidity': minor
---

`Math`: Add `add512`, `mul512` and `mulShr`.
