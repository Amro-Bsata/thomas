---
'openzeppelin-solidity': minor
---

`Math`: Add saturating arithmetic operations `saturatingAdd`, `saturatingSub` and `saturatingMul`.
