---
'openzeppelin-solidity': minor
---

`Strings`: Add `espaceJSON` that escapes special characters in JSON strings.
