module.exports = {
  require: 'hardhat/register',
  timeout: 4000,
};
